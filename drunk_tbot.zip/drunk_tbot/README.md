ROS package is made for ROS Indigo. Tested on Ubuntu 14.04 LTS 64-bit

$roscore
$rosrun turtlesim turtlesim_node
$rosrun drunk_tbot turn_white_background.sh
$rosrun drunk_tbot drunk_cmd_node